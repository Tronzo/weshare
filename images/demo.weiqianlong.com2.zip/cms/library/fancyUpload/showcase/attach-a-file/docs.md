*Experimental interface preview, not fully tested yet.* Inspired by a real-world usage, used in a well-known web-application. Imagine it wrapped in a form to compose 
e-mails ...

**Enabled Validations**

* Selectable file-size is limited to 2 MB

**What will happen?**

* Selecting multiple files
* Instant start
* All files start at once (no queued upload)
* Cancel and remove single file
* Validate size